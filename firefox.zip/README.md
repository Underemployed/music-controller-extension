# music-controller-extension
Pause/Play YouTube Music from any tab using a shortcut
